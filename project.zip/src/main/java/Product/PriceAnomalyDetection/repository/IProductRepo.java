package Product.PriceAnomalyDetection.repository;

import Product.PriceAnomalyDetection.model.Product;

public interface IProductRepo extends IGenericRepo<Product, String>{
}
