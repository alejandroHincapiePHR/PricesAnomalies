package Product.PriceAnomalyDetection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PriceAnomalyDetectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
